/*******************************************************************************
/
/	File:			testdigit.c
/
/   Description:	A simple application that tests the digit driver.
/
/	Copyright 1999, Be Incorporated.   All Rights Reserved.
/	This file may be used under the terms of the Be Sample Code License.
/
*******************************************************************************/

#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <OS.h>

#include <support/SupportDefs.h>

static void dump(uchar *b, int c);

int main()
{
	int fd;
	status_t err;
	uchar c;

	fd = open("/dev/misc/parallelport", O_RDWR);
	if (fd < 0) {
		printf("Error opening device\n");
		return 1;
	}

	c = 255;
	err = write(fd, &c, 1);
	if (err < 0)
		printf("Error setting digit\n");
	while (true) {
		snooze(100000);
		c++;
		err = read(fd, &c, 1);
		printf("digit %d\n", c);
	}
	close(fd);

	return 0;
}

static void dump(uchar *b, int c)
{
	int i;
	for (i=0;i<c;i++) {
		printf("%2.2x ", *(b++));
		if ((i & 15) == 15)
			printf("\n");
	}
	printf("\n");
}
