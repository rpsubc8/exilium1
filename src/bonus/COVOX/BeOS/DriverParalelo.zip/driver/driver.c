/*******************************************************************************
/
/	File:			driver.c
/
/   Description:	The parallelport driver allows a client to read 16 bytes of data.
/                   Each byte has the same value (by default 0); the client
/                   can change this value with write or ioctl commands.
/
/	Copyright 1999, Be Incorporated.   All Rights Reserved.
/	This file may be used under the terms of the Be Sample Code License.
/
*******************************************************************************/

#include <drivers/Drivers.h>
#include <drivers/KernelExport.h>
#include <drivers/ISA.h>

#include <malloc.h>
#include <string.h>

#define DPRINTF(a) dprintf("parallelport: "); dprintf a

#define DEVICE_NAME "misc/parallelport"
//#define MAX_SIZE 16
#define TOUCH(x) ((void)x)

/*********************************/

static status_t
parallelport_open(const char *name, uint32 mode, void **cookie)
{
//	struct parallelport_state *s;

	TOUCH(name); TOUCH(mode);

	DPRINTF(("open\n"));

//	s = (struct parallelport_state*) malloc(sizeof(*s));
//	if (!s)
//		return B_NO_MEMORY;

//	s->value = 0;

	*cookie = NULL;

	return B_OK;
}

static status_t
parallelport_close(void *cookie)
{
	TOUCH(cookie);

	DPRINTF(("close\n"));

	return B_OK;
}

static status_t
parallelport_free(void *cookie)
{
	DPRINTF(("free\n"));

//	free(cookie);

	return B_OK;
}

static status_t
parallelport_ioctl(void *cookie, uint32 op, void *data, size_t len)
{
	TOUCH(len);

	DPRINTF(("ioctl\n"));

	if (op == 'set ') {
//		struct parallelport_state *s = (struct parallelport_state *)cookie;
//		s->value = *(uchar *)data;
//		DPRINTF(("Set parallelport to %2.2x\n", s->value));
		return B_OK;
	}

	return ENOSYS;
}

static status_t
parallelport_read(void *cookie, off_t pos, void *buffer, size_t *len)
{
//	struct parallelport_state *s = (struct parallelport_state *)cookie;

	struct isa_module_info *isa;
	char *data = (char *)malloc(sizeof(char));
	uint8 bla;

	DPRINTF(("read\n"));

	TOUCH(pos);
	get_module(B_ISA_MODULE_NAME , &isa);
	bla = isa->read_io_8(0x379);
	//if(*len)
	memset(buffer, bla, 1);
		
	return B_OK;
}

static status_t
parallelport_write(void *cookie, off_t pos, const void *buffer, size_t *len)
{
//	struct parallelport_state *s = (struct parallelport_state *)cookie;
	char data;
	struct isa_module_info *isa;

	TOUCH(pos);
	data = *((char *) buffer);
	get_module(B_ISA_MODULE_NAME , &isa);
	isa->write_io_8(0x378, data);

//	DPRINTF(("write: set parallelport to %2.2x\n", s->value));

	return B_OK;
}

/***************************/

status_t init_hardware()
{
	DPRINTF(("Do you parallelport?\n"));
	return B_OK;
}

const char **publish_devices()
{
	static const char *devices[] = {
		DEVICE_NAME, NULL
	};

	return devices;
}

device_hooks *find_device(const char *name)
{
	static device_hooks hooks = {
		&parallelport_open,
		&parallelport_close,
		&parallelport_free,
		&parallelport_ioctl,
		&parallelport_read,
		&parallelport_write,
		/* Leave select/deselect/readv/writev undefined. The kernel will
		 * use its own default implementation. The basic hooks above this
		 * line MUST be defined, however. */
		NULL,
		NULL,
		NULL,
		NULL
	};

	if (!strcmp(name, DEVICE_NAME))
		return &hooks;

	return NULL;
}

status_t init_driver()
{
	return B_OK;
}

void uninit_driver()
{
}
